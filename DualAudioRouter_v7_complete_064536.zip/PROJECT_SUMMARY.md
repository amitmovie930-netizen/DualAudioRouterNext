# DualAudioRouter – Complete Project Summary
# Date: 2026-09-28
# Device: Honor Pad 8 (HEY-W09), MagicOS / Android 12

## Goal
Make the Honor Pad 8 play the same media audio on BOTH:
  1. Internal speakers
  2. External Bluetooth A2DP speaker
at the same time (like Samsung Dual Audio).

Also earlier request: increase volume by ~200% while keeping quality (Bluetooth-friendly).

## What we tried

### 1. Volume boost apps (GitHub)
- Recommended: DeciBoost (https://github.com/ayv4zyan/DeciBoost)
  - Uses LoudnessEnhancer + DynamicsProcessing
  - Works with Bluetooth and tries to keep quality
- User has GitHub login + Shizuku + Bugjaeger

### 2. Dual audio app (this project)
- App name: DualAudioRouter
- Package: com.example.dualaudiorouter
- Uses Shizuku UserService (runs as shell UID 2000)
- Calls hidden Android APIs:
  - AudioManager.setPreferredDevicesForStrategy()  ← real dual routing
  - AudioSystem.setForceUse()                     ← only forces speaker

### 3. Result on Honor Pad 8
From logcat:
  Method 1 failed: Missing MODIFY_AUDIO_ROUTING permission
  Method 2 (AudioSystem.setForceUse) SUCCESS

Conclusion:
- Honor / MagicOS blocks MODIFY_AUDIO_ROUTING even for shell UID (Shizuku).
- True simultaneous speaker + Bluetooth is NOT possible without root.
- Root is not safely available for Honor Pad 8 (locked bootloader, no public unlock).

## Current app behaviour (v6 / v7)
- Shizuku permission: Granted
- User service: Connected
- Toggle now STAYS ON when user turns it on
- Status shows "Blocked by Honor" because real dual routing failed
- App still calls the APIs so you can test; only one output will play

## Files in this project
```
.github/workflows/build-apk.yml   ← GitHub Actions workflow
README.md
PROJECT_SUMMARY.md                ← this file
app/build.gradle.kts
app/proguard-rules.pro
app/src/main/AndroidManifest.xml
app/src/main/aidl/.../IDualAudioService.aidl
app/src/main/java/.../DualAudioService.kt
app/src/main/java/.../DualAudioUI.kt
app/src/main/java/.../MainActivity.kt
app/src/main/res/values/strings.xml
build.gradle.kts
gradle.properties
gradle/wrapper/gradle-wrapper.properties
settings.gradle.kts
```

## How to build (GitHub Actions)
1. Put ALL source files at repo root (not inside a zip).
2. Workflow file must be at: .github/workflows/build-apk.yml
3. Go to Actions → Build Debug APK → Run workflow
4. Download APK from Artifacts

OR use the simple workflow (no zip extraction) that expects source at root.

## Alternative solutions (recommended)
Because software dual audio is blocked on Honor:

1. Hardware: USB-C dual Bluetooth transmitter
   - Tablet sends one stream → transmitter sends to two Bluetooth speakers
2. Accept single output and switch quickly via media output panel
3. Use DeciBoost only for volume boost on whichever output is active

## Root status
- Honor Pad 8 (HEY-W09, Snapdragon 680): bootloader unlock not publicly available
- Official codes discontinued; paid/test-point methods high brick risk
- Not recommended

## What the user still wants
- Toggle that stays ON (fixed in this version)
- Simultaneous internal + Bluetooth audio (blocked by OEM)
- Or best possible workaround

## Contact / restore context
If this conversation is lost, upload this PROJECT_SUMMARY.md + the project zip
and say: "Continue DualAudioRouter for Honor Pad 8 – dual speaker + Bluetooth"
