package com.example.dualaudiorouter

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DualAudioUI(
    dualToggleOn: Boolean,
    dualReallyActive: Boolean,
    serviceConnected: Boolean,
    shizukuPermissionGranted: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Dual Audio Router",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        StatusCard("Shizuku permission", if (shizukuPermissionGranted) "Granted" else "Not granted")
        StatusCard("User service", if (serviceConnected) "Connected" else "Disconnected")
        StatusCard(
            "Dual routing result",
            if (dualReallyActive) "ACTIVE (both outputs)" else "Blocked by Honor"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Toggle stays ON when user turns it on
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Dual Audio", fontSize = 18.sp)
            Switch(
                checked = dualToggleOn,
                onCheckedChange = { enabled -> onToggle(enabled) },
                enabled = serviceConnected && shizukuPermissionGranted
            )
        }

        if (dualToggleOn && !dualReallyActive) {
            Text(
                "Toggle is ON, but system blocked dual routing.\nYou will hear only one output.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.error
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.errorContainer
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "Honor / MagicOS limitation",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "This tablet blocks MODIFY_AUDIO_ROUTING even under Shizuku (shell UID).\n\n" +
                    "True simultaneous speaker + Bluetooth is not possible without root.\n\n" +
                    "Turning the toggle ON still attempts the APIs, but only one output will play. " +
                    "This is expected on Honor Pad 8.",
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            "How to test:\n" +
            "1. Start Shizuku\n" +
            "2. Pair a Bluetooth speaker\n" +
            "3. Open this app (permission should be Granted)\n" +
            "4. Toggle Dual Audio ON\n" +
            "5. Play YouTube / music\n\n" +
            "If only one speaker works → normal on this device.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StatusCard(title: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title)
            Text(value, fontWeight = FontWeight.Medium)
        }
    }
}
